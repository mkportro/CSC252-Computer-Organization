#define _POSIX_SOURCE

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/time.h>
#include <unistd.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>

void sig_handler(int sig);

pid_t PID;
int success = 0; //<0 if child succeeds
int sigNum = 0;
//int timeout = 0; //==1 if child timed out

void sig_handler(int sig) {
  kill(PID, SIGKILL);
  //timeout++;
} 

/* An example of a call to confine will look like this: ./confine ./samples/sub1 1 2 3 0
   This will cause confine to execute ./samples/sub1 with the arguments 1 2 3 0. */

int main(int argc, char *argv[]) {
  if(argc == 1) {
	fprintf(stderr, "Usage: %s /path/to/program args...\n", argv[0]);
	exit(1);
  }

  /* alarm & signal handle before fork, fork, set limits in child, call exec w/ argument, handle signal will tell fail or success,
      exit, go to parent and handle fail/succeed */
  
  //signal handling
  struct sigaction sa;
  sa.sa_handler = &sig_handler;
  //alarm - "this set up should be done in the parent, before fork()"
  alarm(60);
  //kill(PID, SIGKILL);
  sigaction(SIGALRM, &sa, NULL);
  
  //fork
  /* CHILD */
  if ((PID = fork()) == 0) {
    //set limits - "call setrlimit in the child process after fork() but before execve()"
    struct rlimit *mem_limit, *file_limit, *time_limit;
    mem_limit->rlim_cur = mem_limit->rlim_max = (64*1024*1024);
    file_limit->rlim_cur = file_limit->rlim_max = (4*1024*1024);
    time_limit->rlim_cur = time_limit->rlim_max = 60;
    getrlimit(RLIMIT_AS, mem_limit); //memory <= 64MB (64x1024x1024 bytes)
    getrlimit(RLIMIT_FSIZE, file_limit); //file size <= 4MB (4x1024x1024 bytes)
    getrlimit(RLIMIT_CPU, time_limit); //60 sec
    setrlimit(RLIMIT_AS, mem_limit);
    setrlimit(RLIMIT_FSIZE, file_limit);
    setrlimit(RLIMIT_CPU, time_limit);
    execv(argv[1], &argv[2]);
  }
  /* PARENT */
  else {
    int child_status;
    wait(&child_status);

    //check child return
    if (WIFEXITED(child_status)) { //returns true if the child terminated normally
      success = WEXITSTATUS(child_status); //returns the exit status of the child
    } else if (WIFSIGNALED(child_status)) { //returns true if the child process was terminated by a signal
      sigNum = WTERMSIG(child_status); //returns the number of the signal that caused the child process to terminate
    }
  }

  //create file confine_result.txt
  //  line 1 - confined program and args
  //  line 2 - "normal" "terminated" or "timeout"
  //return vals
  //  127 - encountered restriction
  //  128 - encountered bug
  //  
  FILE *f = fopen("confine_result.txt", "w");
  for (int i = 0; i < argc; i++) {
    fputs(argv[i], f);
    fputs(" ", f);
  }
  fputs("\n", f);
  if (sigNum == SIGALRM) {
    fputs("TIMEOUT", f);
    success = 127;
  } else if (sigNum == SIGSEGV || sigNum == SIGXFSZ) {
    fputs("TERMINATED", f);
    success = 127;
  }
  /*
  if (sigNum == 11 || sigNum == 25) { //11-inval mem ref; 25-file size limit
    printf("sigNum = %d", sigNum);
    fputs("TERMINATED", f);
    success = 127;
  } else if (sigNum == 14) { //14-timer sig
    printf("sigNum = %d", sigNum);
    fputs("TIMEOUT", f);
    success = 127;
  }*/
  else if (success < 0) { //bug
    printf("sucess = %d", sigNum);
    fputs("TERMINATED", f);
    success = 128;
  } else {
    printf("sucess = %d", sigNum);
    fputs("NORMAL", f);
  }
  fclose(f);
  return success;
}